oracle-instantclient Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the oracle-instantclient cookbook.

v1.0.4 (2014-01-18)
-------------------

Re-release v1.0.1 as v1.0.4 due to misnumbering of devodd releases


v1.0.1 (2014-01-18)
-------------------

Fix broken SDK install on i386

v1.0.0
-------------------
Initial 1.0 release.

### Improvement
- #1 - Add new recipes to install SDK and OCI8 Ruby driver.

v0.1.0
-------------------
Initial release.
